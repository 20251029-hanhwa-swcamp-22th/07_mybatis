package com.kang.section01.xmlconfig;

import org.apache.ibatis.session.SqlSession;

import java.util.List;

import static com.kang.section01.xmlconfig.template.getSqlSession;

/* Service 계층
* - 비즈니스 로직 처리 계층
* - 데이터 가공 또는 DAO(DB CRUD) 호출, 트랜잭션 관리
* */
public class MenuService {

    private final MenuDAO menuDAO;

    public MenuService() {
        this.menuDAO = new MenuDAO();
    }

    /**
     * 전체 메뉴 조회
     * @return menuList
     * */
    public List<MenuDTO> selectAllMenu() {

        // 1. SqlSession 얻어오기
        SqlSession sqlSession = template.getSqlSession();

        // 2. SQL 수행 후 결과 반환 받기
        List<MenuDTO> menuList = menuDAO.selectAllmenu(sqlSession);

        // 3. SqlSession 메모리 반환
        sqlSession.close();

        // 4. 결과 반환
        return  menuList;

    }

    public MenuDTO selectMenuByMenuCode(int menuCode) {
 
        return null;
    }

    public boolean registMenu(MenuDTO menu) {

        return false;
    }

    /* 메소드명, id 등 : updateMenu */
    public boolean modifyMenu(MenuDTO menu) {

        return false;
    }

    /* 메소드명, id 등 : deleteMenu */
    public boolean deleteMenu(int menuCode) {

         return false;
    }

}