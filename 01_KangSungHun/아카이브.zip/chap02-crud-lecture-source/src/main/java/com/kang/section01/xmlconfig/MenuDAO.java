package com.kang.section01.xmlconfig;

import org.apache.ibatis.session.SqlSession;

import java.util.List;

/* DAO(Data Access Object, DB 접근 객체)
* - 실질적으로 DB에 연결되는 객체
* - SQL을 수행하고 결과를 반환 받는 역할
* */
public class MenuDAO {
    public List<MenuDTO> selectAllmenu(SqlSession sqlSession) {

        // sqlSession.SQL호출메서드(namespace.id)
        return sqlSession.selectList("MenuMapper.selectAllMenu");
    }
}
